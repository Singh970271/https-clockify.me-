import React from 'react'

const Tags = () => {
  return (
    <div>Tags</div>
  )
}

export default Tags