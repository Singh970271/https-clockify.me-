import React from 'react'

const Project = () => {
  return (
    <div>Project</div>
  )
}

export default Project